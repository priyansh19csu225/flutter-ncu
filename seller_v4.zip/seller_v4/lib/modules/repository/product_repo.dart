import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:seller_app/modules/models/product.dart';
import 'package:seller_app/utils/constants.dart';

class ProductRepository {
  FirebaseFirestore db = FirebaseFirestore.instance;
  add(Product product) {
    Future<DocumentReference> future =
        db.collection(Collections.PRODUCT).add(product.toJSON());
    return future;
  }

  read() {
    // List of Products
    // View in List View
    // CircularProgressIndicator
  }
}
