import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:seller_app/modules/models/product.dart';
import 'package:seller_app/modules/repository/product_repo.dart';
import 'package:seller_app/modules/widgets/custom_text.dart';
import 'package:seller_app/utils/toast.dart';

class AddProduct extends StatelessWidget {
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController descCtrl = TextEditingController();
  TextEditingController qtyCtrl = TextEditingController();
  _addProduct() {
    String name = nameCtrl.text;
    String desc = descCtrl.text;
    double qty = double.parse(qtyCtrl.text);
    Product product = Product.takeProduct(
        name: name, price: priceValue, qty: qty, desc: desc);
    ProductRepository productRepository = ProductRepository();
    Future<DocumentReference> future = productRepository.add(product);
    future
        .then((value) => createToast('Record Added', ctx))
        .catchError((err) => print(err));
  }

  double priceValue = 0.0;
  late BuildContext ctx;
  @override
  Widget build(BuildContext context) {
    this.ctx = context;
    return Column(
      children: [
        Text(
          'ADD Product',
          style: TextStyle(fontSize: 40),
        ),
        CustomText(label: 'Type Name Here', tc: nameCtrl),
        CustomText(
          label: 'Type Desc Here',
          tc: descCtrl,
          isMultiLine: true,
        ),
        Slider(
          value: priceValue,
          onChanged: (currentValue) {
            priceValue = currentValue;
          },
        ),
        // Image Upload
        CustomText(label: 'Type Qty Here', tc: qtyCtrl),
        ElevatedButton(
            onPressed: () {
              _addProduct();
            },
            child: Text('Add Product'))
      ],
    );
  }
}
