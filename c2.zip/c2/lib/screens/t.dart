import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class T extends StatelessWidget {
  const T({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(child: Text('Hello Flutter', style: GoogleFonts.pacifico(
          fontSize: 30
        ),),),
    );
  }
}