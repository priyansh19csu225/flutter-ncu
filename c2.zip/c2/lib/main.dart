import 'package:firstapp/screens/home.dart';
import 'package:firstapp/screens/second.dart';
import 'package:firstapp/screens/stackdemo.dart';
import 'package:firstapp/screens/ted.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'screens/t.dart';

void main(){
  runApp(MaterialApp(
     debugShowCheckedModeBanner: false,
     //home: T(),
   // home: SafeArea(child: Text('Hello Flutter')),
   //home:Second()
   //home:StackDemo()
   home:Ted()
  ));
}