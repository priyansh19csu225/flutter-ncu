import 'package:dio/dio.dart';

tokenInterceptor(Dio dio){
  dio.interceptors.add(InterceptorsWrapper(
    onResponse: (response, handler){
        return handler.next(response);
    },
    onError: (err, handler){
      return handler.next(err);
    },
    onRequest:(options, handler){
     // Do something before request is sent
     return handler.next(options); //continue
     // If you want to resolve the request with some custom data，
     // you can resolve a `Response` object eg: `handler.resolve(response)`.
     // If you want to reject the request with a error message,
     // you can reject a `DioError` object eg: `handler.reject(dioError)`
    },
}