abstract class AppConstants {
  static final int SUCCESS = 1;
}
