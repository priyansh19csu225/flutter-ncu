import 'package:blocdemo/cubit/counter_cubit.dart';
import 'package:blocdemo/cubit/cubit_state.dart';
import 'package:blocdemo/screens/countapp.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  runApp(MaterialApp(
    // Here we create the Instance of
    //BlocCubit and this object is avaliable in widget tree
    //home: BlocProvider(create: (context) => CounterCubit(0), child: CountApp()),
    home: BlocProvider(
      create: (context) => CounterCubit(CustomCubitState(0, 0)),
      child: CountApp(),
    ),
  ));
}
