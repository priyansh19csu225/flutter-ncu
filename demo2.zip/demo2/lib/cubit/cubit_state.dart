class CustomCubitState {
  late int first;
  late int second;
  CustomCubitState(this.first, this.second);
}
