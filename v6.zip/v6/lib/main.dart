import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:seller_app/config/routes.dart';
import 'package:seller_app/core/auth/screens/login.dart';
import 'package:seller_app/utils/constants.dart';
import 'package:seller_app/utils/theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    theme: getTheme(),
    //theme: ThemeData.dark(),
    initialRoute: RouteConstants.LOGIN, // This is the Initial or Base Route
    routes: getRoutes(), // All Routes are loaded Here
  ));
}
