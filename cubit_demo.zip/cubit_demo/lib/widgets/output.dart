import 'package:flutter/material.dart';

class Output extends StatelessWidget {
  const Output({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text(
        'Count value is ',
        style: TextStyle(fontSize: 40),
      ),
    );
  }
}
