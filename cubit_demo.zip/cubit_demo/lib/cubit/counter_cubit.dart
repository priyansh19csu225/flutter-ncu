import 'package:flutter_bloc/flutter_bloc.dart';

// To create Cubit (Function Based ) we need to extends Cubit
class CounterCubit extends Cubit<int> {
  // Create a Paramterized Constructor ,
  //which take initialState Value and call the
  //parent class constructor
  CounterCubit(int initialState) : super(initialState);

  // Create Operations (Functions ) call from the UI / Widget
  void plus() {
    //  Logic Stuff or Ur calling some other logic (Service, Reposoitory, Helper)
    emit(state + 1);
    // Fire the Event so Listener on Another Widget can listen the changes
  }
  // Other Operation
}
