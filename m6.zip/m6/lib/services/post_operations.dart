class PostOperations {
  static PostOperations _opr = PostOperations._();
  PostOperations._() {}

  static PostOperations getInstance() {
    return _opr;
  }
}
