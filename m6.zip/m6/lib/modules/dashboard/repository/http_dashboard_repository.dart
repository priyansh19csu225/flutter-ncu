import 'package:music_app/models/song.dart';
import 'package:music_app/modules/dashboard/repository/dashboard_repository.dart';
import 'package:music_app/utils/services/api_client.dart';

class HttpDashBoardRepository implements DashBoardRespository {
  late ApiClient apiClient;
  @override
  Future<Song> getSongs({String artistName = "Sonu Nigam"}) {
    // TODO: implement getSongs
    throw UnimplementedError();
  }
}
