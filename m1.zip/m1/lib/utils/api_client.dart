import 'package:http/http.dart' as http;

class ApiClient{
  getSongs(){
    // 
    const URL = "https://itunes.apple.com/search?term=sonunigam&limit=25";
    Future<http.Response> future = http.get(Uri.parse(URL));
    future.then((response){
      String json = response.body;
      print("JSON $json");
      print(json.runtimeType);
    }).catchError((err)=>print(err));
    //post(url)
  }
}