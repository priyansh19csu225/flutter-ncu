import 'package:flutter/material.dart';
import 'package:seller_app/modules/widgets/add_product.dart';
import 'package:seller_app/modules/widgets/view_product.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({Key? key}) : super(key: key);

  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  List<Map<String, dynamic>> _loadAllPages() {
    return [
      {'page': AddProduct(), 'title': 'Add Product'},
      {'page': ViewProduct(), 'title': 'View Product'},
    ];
  }

  late List<Map<String, dynamic>> _allPages = _loadAllPages();
  initState() {
    super.initState();
  }

  int currentPage = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: currentPage,
          onTap: (int currentPageIndex) {
            currentPage = currentPageIndex;
            setState(() {});
          },
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.add), label: 'Add Product'),
            BottomNavigationBarItem(
                icon: Icon(Icons.list), label: 'View Product')
          ],
        ),
        //body: SafeArea(child: AddProduct()),
        body: SafeArea(child: _allPages[currentPage]['page']));
  }
}
