import 'package:flutter/material.dart';
import 'package:seller_app/modules/widgets/custom_text.dart';

class AddProduct extends StatelessWidget {
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController descCtrl = TextEditingController();
  TextEditingController qtyCtrl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'ADD Product',
          style: TextStyle(fontSize: 40),
        ),
        CustomText(label: 'Type Name Here', tc: nameCtrl),
        CustomText(
          label: 'Type Desc Here',
          tc: descCtrl,
          isMultiLine: true,
        ),
        Slider(
          value: 1,
          onChanged: (currentValue) {},
        ),
        // Image Upload
        CustomText(label: 'Type Qty Here', tc: qtyCtrl),
        ElevatedButton(onPressed: () {}, child: Text('Add Product'))
      ],
    );
  }
}
