import 'package:flutter/material.dart';
import '/screens/list_of_songs.dart';

void main(){
  runApp(MaterialApp(
    title: 'Music App 2022',
    home: ListOfSongs(),

  ));
}