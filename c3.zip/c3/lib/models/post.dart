class Post{
  late String title;
  late String author;
  late String time;
  late String imageURL;
  Post({required this.title, required this.author, required this.time, required this.imageURL});

}