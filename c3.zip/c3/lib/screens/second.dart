import 'package:flutter/material.dart';

class Second extends StatelessWidget {
  const Second({ Key? key }) : super(key: key);

  _getContainer(Color color, {double width = 50, double height = 50}){
    return Container(
        color:  color,
        width: width,
        height: height,
    );
  }

  _getText(String txt, {double fontSize = 18}){
    return Text(txt, style: TextStyle(fontSize: fontSize),);
  }

  _getImages(String url ,{int flex =1}){
   return  Expanded(child: Image.network(url), flex: flex,);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: 
      Column(
        //Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        //crossAxisAlignment: CrossAxisAlignment.baseline,
        //textBaseline: TextBaseline.ideographic,
        //mainAxisSize: MainAxisSize.max,
       // mainAxisSize: MainAxisSize.min, // Pack the Content
        children: [
          _getImages('https://imgd.aeplcdn.com/0x0/n/cw/ec/52639/3-series-gran-limousine-exterior-right-front-three-quarter-2.jpeg'),
          _getImages('https://i.ytimg.com/vi/fjsy309KJ1Q/maxresdefault.jpg', flex: 3),
          _getImages('https://www.bmw-deutschemotoren.in/sites/default/files/2022-01/500x542_0.jpg', flex: 2)
          // _getText('Hi'),
          // _getText('Hello', fontSize: 40),
          // _getText('Hola')
        // _getContainer(Colors.red), _getContainer(Colors.green, width: 100, height: 100)
        // , _getContainer(Colors.blue)
      ],)
      ,),
    );
  }
}